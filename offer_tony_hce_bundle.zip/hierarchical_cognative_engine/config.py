
import os

TICK_L0 = float(os.environ.get("HCE_TICK_L0", "0.05"))  # 20Hz
TICK_L1 = float(os.environ.get("HCE_TICK_L1", "0.75"))  # ~1.3Hz
TICK_L2 = float(os.environ.get("HCE_TICK_L2", "30"))    # 0.033Hz (every 30s)

MODEL = os.environ.get("HCE_MODEL", "naama-uncensored:latest")
STORE_DIR = os.environ.get("HCE_STORE", "./store")

MAX_HINT_MAGNITUDE = 0.3     # fraction of parameter range
MAX_PENDING_INTENTS = 1000
