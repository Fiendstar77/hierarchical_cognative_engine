
import os, threading, signal, sys, json, time
from .config import TICK_L0, TICK_L1, TICK_L2, MODEL, STORE_DIR
from .store import Store
from .queues import LOGQ
from .loops.kernel import run as run_l0
from .loops.subcog import run as run_l1
from .loops.llm_conscious import run as run_l2
from .mediator import run as run_mediator

stop = False
def _stop(): 
    global stop; stop = True

def main():
    store = Store(STORE_DIR)
    guard = None
    # try load policy
    try:
        import json, pathlib
        p = pathlib.Path(__file__).parent / "policies" / "example_policy.json"
        guard = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        guard = {"ceilings":{}}

    threads = []
    threads.append(threading.Thread(target=run_l0, kwargs={"tick": TICK_L0, "stop_flag": lambda: stop}, daemon=True))
    threads.append(threading.Thread(target=run_l1, kwargs={"tick": TICK_L1, "stop_flag": lambda: stop, "store": store}, daemon=True))
    threads.append(threading.Thread(target=run_l2, kwargs={"tick": TICK_L2, "stop_flag": lambda: stop, "model": MODEL, "policy": guard, "store": store}, daemon=True))
    threads.append(threading.Thread(target=run_mediator, kwargs={"stop_flag": lambda: stop, "store": store, "guard": guard}, daemon=True))

    for t in threads: t.start()

    print("HCE running. Press Ctrl+C to stop.")
    try:
        while not stop:
            log = LOGQ.pop()
            if log:
                store.append_audit("log", log)
            time.sleep(0.1)
    except KeyboardInterrupt:
        _stop()
    finally:
        print("HCE stopping...")
        time.sleep(0.5)

if __name__ == "__main__":
    main()
