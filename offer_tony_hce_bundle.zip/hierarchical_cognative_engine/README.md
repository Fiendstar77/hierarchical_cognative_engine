
# Hierarchical Cognative Engine (with LLM slow loop)

This bundle is a minimal, runnable scaffold that implements Tony’s idea:
> *"take the heirarchical_cognatative_engine folder that i have and add the LLM as a slower loop on top of that with a mechanism to indirectly make changes to the lower levels—kinda like how conscious thoughts seep into our subconscious."*

## Overview

- **L0 Kernel (10–20Hz)**: fast ticks, collects signals, pushes to queues.
- **L1 Sub-Cognitive (1–2Hz)**: handles habits/skills; consumes tasks, updates state.
- **L2 Conscious LLM (0.01–0.1Hz)**: slow “thoughts” over transcripts/telemetry.
  - Produces **INTENTS** and **POLICY HINTS** (not direct edits).
  - A **Mediator** applies hints to L1/L0 via *indirect* knobs: priorities, thresholds, and scheduled tasks.
  - All changes are **audited** and **reversible**.

## Run

```bash
python -m hierarchical_cognative_engine.run
```

Optional env vars:
- `HCE_MODEL=naama-uncensored:latest` (any `ollama run`-able model)
- `HCE_TICK_L0=0.05`  (seconds)
- `HCE_TICK_L1=0.75`
- `HCE_TICK_L2=30`
- `HCE_STORE=./store` (persistence dir)

## Key design ideas

- **Indirection**: L2 never mutates L1/L0 code or state directly; it files requests (`INTENT`) and the **Mediator** turns them into small, typed knobs or scheduled tasks.
- **Conservation of Habit**: L1 may **reject** an intent if it violates guardrails or degrades performance.
- **Traceability**: every applied hint has an `intent_id`, `diff`, and rollback plan.
- **Safety**: ban-lists and ceilings prevent runaway parameter growth.

## Files

- `run.py` — entrypoint, spawns loops and mediator
- `loops/kernel.py` — L0 fast loop
- `loops/subcog.py` — L1 sub-cognitive loop
- `loops/llm_conscious.py` — L2 slow LLM loop (Ollama)
- `mediator.py` — intent → hint application, guardrails, rollback
- `queues.py` — simple in-proc queues
- `store.py` — JSONL persistence for audit and state
- `config.py` — tick rates, limits
- `diagrams/engine.mmd` — Mermaid diagram
- `policies/example_policy.json` — example guardrails/knobs
