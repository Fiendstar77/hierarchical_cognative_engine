
from collections import deque
from threading import Lock

class SafeQueue:
    def __init__(self, maxlen=1024):
        self.q = deque(maxlen=maxlen)
        self.lock = Lock()
    def push(self, item):
        with self.lock:
            self.q.append(item)
    def pop(self):
        with self.lock:
            return self.q.popleft() if self.q else None
    def __len__(self):
        with self.lock:
            return len(self.q)

# Shared queues
IQ = SafeQueue(2048)     # inputs / observations
TASKQ = SafeQueue(1024)  # tasks for L1
INTENTS = SafeQueue(1024) # L2 → Mediator suggested intents
HINTS = SafeQueue(1024)   # Mediator → L1 indirect hints
LOGQ = SafeQueue(4096)
