
import uuid, math
from .queues import INTENTS, HINTS
from .store import now
from .config import MAX_HINT_MAGNITUDE

def sanitize_delta(val, lo=-1.0, hi=1.0):
    try:
        v = float(val)
    except Exception:
        v = 0.0
    return max(lo, min(hi, v))

def intent_to_hints(intent, guard):
    t = (intent.get("type") or "").lower()
    if t == "adjust_param":
        name = intent.get("param")
        raw = sanitize_delta(intent.get("delta", 0.0))
        mag = MAX_HINT_MAGNITUDE * raw
        # apply guard ceilings
        if guard and name in guard.get("ceilings", {}):
            mag = max(-guard["ceilings"][name], min(guard["ceilings"][name], mag))
        return [{"param": name, "delta": mag}]
    elif t == "schedule_task":
        # For simplicity, convert into priority_scale nudge
        return [{"param":"priority_scale", "delta": 0.05}]
    elif t == "set_priority":
        return [{"param":"priority_scale", "delta": sanitize_delta(intent.get("weight",0.0))*0.1}]
    return []

def run(stop_flag=lambda: False, store=None, guard=None):
    while not stop_flag():
        it = INTENTS.pop()
        if not it:
            # small cooperative yield
            import time; time.sleep(0.05); continue
        it["intent_id"] = str(uuid.uuid4())
        hints = intent_to_hints(it, guard or {})
        for h in hints:
            HINTS.push({**h, "intent_id": it["intent_id"], "ts": now()})
        if store:
            store.append_audit("intent_mediated", {"intent": it, "hints": hints})
