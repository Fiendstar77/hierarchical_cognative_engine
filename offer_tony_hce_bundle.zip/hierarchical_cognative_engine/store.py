
import os, json, time
from pathlib import Path

def now():
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())

class Store:
    def __init__(self, base="./store"):
        self.base = Path(base); self.base.mkdir(parents=True, exist_ok=True)
        (self.base/"audit").mkdir(exist_ok=True)

    def append_audit(self, kind, payload):
        p = self.base/"audit"/f"{kind}.jsonl"
        with p.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"ts": now(), **payload}, ensure_ascii=False) + "\n")

    def save_state(self, name, obj):
        p = self.base/f"{name}.json"
        p.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")

    def load_state(self, name, default=None):
        p = self.base/f"{name}.json"
        if not p.exists(): return default
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return default
