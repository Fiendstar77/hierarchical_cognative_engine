
import time, random
from ..queues import IQ, LOGQ
from ..store import now

def run(tick=0.05, stop_flag=lambda: False):
    while not stop_flag():
        # Simulate raw observations
        IQ.push({"t": now(), "obs": {"load": random.random(), "signal": random.choice(["idle","ping","burst"])}})
        LOGQ.push({"kind":"l0_tick"})
        time.sleep(tick)
