
import time
from ..queues import TASKQ, HINTS, LOGQ
from ..store import now

# example parameters ("habits")
STATE = {
    "retrieval_k": 4,
    "threshold": 0.6,
    "priority_scale": 1.0,
}

RANGES = {
    "retrieval_k": (1, 12),
    "threshold": (0.1, 0.95),
    "priority_scale": (0.5, 2.0),
}

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def apply_hint(hint):
    # applies tiny adjustments
    name = hint.get("param")
    delta = hint.get("delta", 0.0)
    if name not in STATE: return False, "unknown_param"
    lo, hi = RANGES[name]
    new = clamp(STATE[name] + delta, lo, hi)
    STATE[name] = new
    return True, "ok"

def run(tick=0.75, stop_flag=lambda: False, store=None):
    while not stop_flag():
        # absorb hints
        hint = HINTS.pop()
        while hint:
            ok, msg = apply_hint(hint)
            if store:
                store.append_audit("hints_applied", {"hint": hint, "ok":ok, "msg":msg, "state": STATE.copy()})
            hint = HINTS.pop()

        # execute tasks
        task = TASKQ.pop()
        if task and store:
            store.append_audit("task_exec", {"task": task, "state": STATE.copy()})
        LOGQ.push({"kind":"l1_tick", "state": STATE.copy()})
        time.sleep(tick)
