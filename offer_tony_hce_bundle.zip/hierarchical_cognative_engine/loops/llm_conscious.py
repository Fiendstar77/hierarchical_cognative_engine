
import time, json, subprocess
from ..queues import IQ, INTENTS, LOGQ
from ..store import now

def ollama_run(model, prompt):
    try:
        proc = subprocess.run(["ollama","run",model], input=prompt.encode("utf-8"),
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        if proc.returncode != 0:
            return f"(model error: {proc.stderr.decode(errors='ignore').strip()})"
        return proc.stdout.decode("utf-8", errors="ignore")
    except FileNotFoundError:
        return "(ollama not found)"

def build_prompt(observations, policy):
    # summarize observations; in practice you would include more structure
    recent = observations[-6:]
    obs_lines = ["- " + json.dumps(o) for o in recent]
    policy_hint = json.dumps(policy, ensure_ascii=False)
    return f"""You are the slow conscious loop.
Recent observations:
{chr(10).join(obs_lines)}

Policy (JSON): {policy_hint}

Propose 1-3 INTENTS to improve performance indirectly. For each INTENT:
- type: one of ["schedule_task","adjust_param","set_priority"]
- rationale: short
- magnitude: small deltas only
Output strict JSON list.
"""

def run(tick=30.0, stop_flag=lambda: False, model="naama-uncensored:latest", policy=None, store=None):
    observations = []
    while not stop_flag():
        # collect a small batch of observations from IQ (non-blocking)
        o = IQ.pop()
        while o:
            observations.append(o)
            observations = observations[-100:]
            o = IQ.pop()

        prompt = build_prompt(observations, policy or {})
        reply = ollama_run(model, prompt)
        if store:
            store.append_audit("l2_reply_raw", {"reply": reply})

        # try to parse JSON list
        intents = []
        try:
            intents = json.loads(reply)
            if not isinstance(intents, list):
                intents = []
        except Exception:
            pass

        for it in intents[:3]:
            it["ts"] = now()
            INTENTS.push(it)
        LOGQ.push({"kind":"l2_tick","intents": len(intents)})
        time.sleep(tick)
